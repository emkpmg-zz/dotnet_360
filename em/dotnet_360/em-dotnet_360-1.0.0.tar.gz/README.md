# Ansible Collection - em.dotnet_360

Documentation for the collection.

## dotnet_360 
<p> 
dotnet_360 ansible package is a one in all solution for installing any version of Microsoft .NET core SDK, .NET core runtime and .NET framework.
(Includes devpack, windows devpack, windowshosting and other variations).
Role can be added in playbook and specific versions can be referenced. </p>

## Install a collection from a private github repository
ansible-galaxy collection install git@github.com:organization/repo_name.git
